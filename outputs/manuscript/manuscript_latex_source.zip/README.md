# Manuscript: Do Unknown Scenarios Arrive as a Poisson Process?

Venue-neutral journal draft (August 2026) — Samer Jameel & Xinhai Zhang.

## Contents
- main.tex        — the manuscript (article class, single column, line numbers on)
- refs.bib        — bibliography (natbib, numeric style)
- figures/        — figures exported from the simulator's run outputs and studies

## Build
latexmk -pdf main.tex
(or: pdflatex main && bibtex main && pdflatex main && pdflatex main)

## Adapting to a journal
- Replace the documentclass/preamble with the journal template; sections, math,
  tables, and \cite keys carry over unchanged.
- Fill in: affiliations, acknowledgements, data-availability repository/DOI.
- Line numbers: remove \usepackage{lineno} and \linenumbers if not wanted.
- Company anonymization is already applied throughout.
